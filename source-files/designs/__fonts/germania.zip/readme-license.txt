The font Germania has been created by Dieter Steffmann. It has been published as a "free for personal use" font.

You can find the original download page at:
https://www.dafont.com/germania.font

You can visit the author's website at:
http://www.steffmann.de/